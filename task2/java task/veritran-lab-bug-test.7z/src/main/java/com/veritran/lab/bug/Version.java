package com.veritran.lab.bug;

public class Version {

    public static final String VERSION_STRING = "0.2343434.0";

}

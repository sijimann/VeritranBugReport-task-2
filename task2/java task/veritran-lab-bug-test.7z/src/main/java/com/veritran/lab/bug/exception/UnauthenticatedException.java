package com.veritran.lab.bug.exception;

/**
 * Created by Bruce A. Grobler on 9/10/14.
 */
public class UnauthenticatedException extends Exception {

    public UnauthenticatedException() {
        super();
    }

    public UnauthenticatedException(String message) {
        super(message);
    }

}
